globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/w8M9LjeNE1P0haw-U_ogH/_buildManifest.js",
    "static/w8M9LjeNE1P0haw-U_ogH/_ssgManifest.js",
    "static/w8M9LjeNE1P0haw-U_ogH/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0j1we3cwg31qe.js",
    "static/chunks/374e0i9_p69m6.js",
    "static/chunks/0c1s5fk-slqw9.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/374e0i9_p69m6.js",
        "static/chunks/0c1s5fk-slqw9.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/374e0i9_p69m6.js",
        "static/chunks/0c1s5fk-slqw9.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/0j1we3cwg31qe.js",
        "static/chunks/374e0i9_p69m6.js",
        "static/chunks/0c1s5fk-slqw9.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
