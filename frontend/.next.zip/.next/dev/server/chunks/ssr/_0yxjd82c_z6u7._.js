module.exports = [
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-ssr] (ecmascript)").vendored['react-ssr'].ReactJsxDevRuntime;
}),
"[project]/src/components/AnswerBody.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "answer": "AnswerBody-module__RjDa-G__answer",
  "caret": "AnswerBody-module__RjDa-G__caret",
});
}),
"[project]/src/components/AnswerBody.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AnswerBody
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$citations$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/citations.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/format.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AnswerBody$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/AnswerBody.module.css [app-ssr] (css module)");
;
;
;
;
function Inline({ text }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseInline"])(text).map((segment, i)=>segment.bold ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                children: segment.text
            }, i, false, {
                fileName: "[project]/src/components/AnswerBody.tsx",
                lineNumber: 10,
                columnNumber: 11
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: segment.text
            }, i, false, {
                fileName: "[project]/src/components/AnswerBody.tsx",
                lineNumber: 12,
                columnNumber: 11
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/AnswerBody.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
function AnswerBody({ text, caret = false }) {
    const blocks = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$format$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseAnswer"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$citations$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["stripCitations"])(text));
    const cursor = caret ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AnswerBody$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].caret,
        "aria-hidden": "true"
    }, void 0, false, {
        fileName: "[project]/src/components/AnswerBody.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this) : null;
    const lastBlock = blocks.length - 1;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AnswerBody$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].answer,
        children: [
            blocks.map((block, i)=>{
                const tail = i === lastBlock ? cursor : null;
                if (block.type === "p") return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Inline, {
                            text: block.text
                        }, void 0, false, {
                            fileName: "[project]/src/components/AnswerBody.tsx",
                            lineNumber: 41,
                            columnNumber: 15
                        }, this),
                        tail
                    ]
                }, i, true, {
                    fileName: "[project]/src/components/AnswerBody.tsx",
                    lineNumber: 40,
                    columnNumber: 13
                }, this);
                const last = block.items.length - 1;
                const items = block.items.map((item, j)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Inline, {
                                text: item
                            }, void 0, false, {
                                fileName: "[project]/src/components/AnswerBody.tsx",
                                lineNumber: 48,
                                columnNumber: 13
                            }, this),
                            j === last ? tail : null
                        ]
                    }, j, true, {
                        fileName: "[project]/src/components/AnswerBody.tsx",
                        lineNumber: 47,
                        columnNumber: 11
                    }, this));
                return block.type === "ol" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                    start: block.start,
                    children: items
                }, i, false, {
                    fileName: "[project]/src/components/AnswerBody.tsx",
                    lineNumber: 53,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                    children: items
                }, i, false, {
                    fileName: "[project]/src/components/AnswerBody.tsx",
                    lineNumber: 57,
                    columnNumber: 11
                }, this);
            }),
            blocks.length === 0 && cursor
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/AnswerBody.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/ChatWidget.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "assistant": "ChatWidget-module__MMKJYW__assistant",
  "avatar": "ChatWidget-module__MMKJYW__avatar",
  "blink": "ChatWidget-module__MMKJYW__blink",
  "bubble": "ChatWidget-module__MMKJYW__bubble",
  "chip": "ChatWidget-module__MMKJYW__chip",
  "contact": "ChatWidget-module__MMKJYW__contact",
  "contactLink": "ChatWidget-module__MMKJYW__contactLink",
  "contactPrimary": "ChatWidget-module__MMKJYW__contactPrimary",
  "contactTitle": "ChatWidget-module__MMKJYW__contactTitle",
  "dots": "ChatWidget-module__MMKJYW__dots",
  "footnote": "ChatWidget-module__MMKJYW__footnote",
  "form": "ChatWidget-module__MMKJYW__form",
  "header": "ChatWidget-module__MMKJYW__header",
  "headerText": "ChatWidget-module__MMKJYW__headerText",
  "iconButton": "ChatWidget-module__MMKJYW__iconButton",
  "input": "ChatWidget-module__MMKJYW__input",
  "launcher": "ChatWidget-module__MMKJYW__launcher",
  "messages": "ChatWidget-module__MMKJYW__messages",
  "note": "ChatWidget-module__MMKJYW__note",
  "notice": "ChatWidget-module__MMKJYW__notice",
  "panel": "ChatWidget-module__MMKJYW__panel",
  "plain": "ChatWidget-module__MMKJYW__plain",
  "retry": "ChatWidget-module__MMKJYW__retry",
  "rise": "ChatWidget-module__MMKJYW__rise",
  "root": "ChatWidget-module__MMKJYW__root",
  "send": "ChatWidget-module__MMKJYW__send",
  "slow": "ChatWidget-module__MMKJYW__slow",
  "sourceChip": "ChatWidget-module__MMKJYW__sourceChip",
  "sources": "ChatWidget-module__MMKJYW__sources",
  "starters": "ChatWidget-module__MMKJYW__starters",
  "stopSquare": "ChatWidget-module__MMKJYW__stopSquare",
  "subtitle": "ChatWidget-module__MMKJYW__subtitle",
  "title": "ChatWidget-module__MMKJYW__title",
  "user": "ChatWidget-module__MMKJYW__user",
});
}),
"[project]/src/components/ChatWidget.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CONTACT_EMAIL",
    ()=>CONTACT_EMAIL,
    "CONTACT_URL",
    ()=>CONTACT_URL,
    "MAX_LENGTH",
    ()=>MAX_LENGTH,
    "default",
    ()=>ChatWidget
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$chatApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/chatApi.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$typewriter$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/typewriter.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AnswerBody$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/AnswerBody.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/ChatWidget.module.css [app-ssr] (css module)");
"use client";
;
;
;
;
;
;
;
const CONTACT_EMAIL = "hello@sharpbuild.io";
const CONTACT_URL = "https://sharpbuild.io/contact";
const MAX_LENGTH = 500; // must match the backend's ChatRequest limit
const STARTERS = [
    "What services do you offer?",
    "Do you build Shopify stores?",
    "How does your process work?",
    "How can I contact you?"
];
function conversationHistory(messages) {
    return messages.filter((message)=>message.role === "user" || message.role === "assistant" && !message.streaming).slice(-6).map((message)=>({
            role: message.role,
            text: message.text
        }));
}
function errorText(error) {
    if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$chatApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ChatApiError"]) {
        switch(error.kind){
            case "rate_limited":
                return `You're asking quickly. Please wait ${error.retryAfterSeconds ?? 30} seconds and try again.`;
            case "network":
                return "I couldn't reach the assistant. Please check your connection and try again.";
            case "invalid":
                return "That message couldn't be sent. Please shorten or rephrase it.";
        }
    }
    return "Something went wrong on our side. Please try again in a moment.";
}
const Icon = ({ d })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        width: "18",
        height: "18",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        "aria-hidden": "true",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: d
        }, void 0, false, {
            fileName: "[project]/src/components/ChatWidget.tsx",
            lineNumber: 102,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/ChatWidget.tsx",
        lineNumber: 91,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
const ICONS = {
    chat: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",
    close: "M18 6 6 18M6 6l12 12",
    send: "m22 2-7 20-4-9-9-4zM22 2 11 13",
    reset: "M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5"
};
function HumanContact() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].contact,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].contactTitle,
                children: "Want to talk to a person?"
            }, void 0, false, {
                fileName: "[project]/src/components/ChatWidget.tsx",
                lineNumber: 115,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].contactPrimary,
                href: `mailto:${CONTACT_EMAIL}`,
                children: "Talk to a human"
            }, void 0, false, {
                fileName: "[project]/src/components/ChatWidget.tsx",
                lineNumber: 116,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].contactLink,
                href: CONTACT_URL,
                target: "_blank",
                rel: "noopener noreferrer",
                children: "Contact page"
            }, void 0, false, {
                fileName: "[project]/src/components/ChatWidget.tsx",
                lineNumber: 119,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ChatWidget.tsx",
        lineNumber: 114,
        columnNumber: 5
    }, this);
}
function ChatWidget({ ask = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$chatApi$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["askQuestionStream"], defaultOpen = false, slowHintMs = 6000, tickMs = 28 }) {
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(defaultOpen);
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [slow, setSlow] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const nextId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(1);
    const loadingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(false);
    const abortRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const streamRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const timerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const listRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(null);
    const panelId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useId"])();
    const hasStreamingText = messages.some((m)=>m.role === "assistant" && m.streaming);
    const stopTimer = ()=>{
        if (timerRef.current) clearInterval(timerRef.current);
        timerRef.current = null;
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>()=>{
            abortRef.current?.abort();
            stopTimer();
        }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (open) inputRef.current?.focus();
    }, [
        open
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const el = listRef.current;
        if (el) el.scrollTop = el.scrollHeight;
    }, [
        messages,
        loading,
        slow
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (!loading || hasStreamingText) {
            setSlow(false);
            return;
        }
        const timer = setTimeout(()=>setSlow(true), slowHintMs);
        return ()=>clearTimeout(timer);
    }, [
        loading,
        hasStreamingText,
        slowHintMs
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (input === "" && inputRef.current) inputRef.current.style.height = "auto";
    }, [
        input
    ]);
    /** Creates or updates the assistant message for the answer being written. */ const show = (state, patch = {})=>{
        const message = {
            id: state.id,
            role: "assistant",
            text: state.received.slice(0, state.shown),
            sources: [],
            needsHuman: false,
            streaming: true,
            ...patch
        };
        setMessages((prev)=>prev.some((m)=>m.id === state.id) ? prev.map((m)=>m.id === state.id ? message : m) : [
                ...prev,
                message
            ]);
    };
    const finish = (state)=>{
        stopTimer();
        streamRef.current = null;
        loadingRef.current = false;
        setLoading(false);
        if (state.error) {
            const partial = state.received.slice(0, state.shown).trim();
            show(state, partial ? {
                text: partial,
                note: "The answer was cut short.",
                needsHuman: true,
                retryQuestion: state.question,
                streaming: false
            } : {
                text: errorText(state.error),
                needsHuman: true,
                retryQuestion: state.question,
                streaming: false
            });
        } else if (state.final) {
            show(state, {
                text: state.final.answer,
                sources: state.final.sources,
                needsHuman: state.final.fallback,
                streaming: false
            });
        }
    };
    const tick = ()=>{
        const state = streamRef.current;
        if (!state) return;
        if (state.shown < state.received.length) {
            state.shown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$typewriter$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["nextShown"])(state.shown, state.received.length);
            show(state);
        }
        // Everything that arrived is visible and the request has ended: show sources and finish.
        if (state.shown >= state.received.length && (state.final || state.error)) finish(state);
    };
    const ensureTimer = ()=>{
        if (!timerRef.current) timerRef.current = setInterval(tick, tickMs);
    };
    const send = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useCallback"])(async (raw, echo = true)=>{
        const text = raw.trim();
        if (!text || loadingRef.current) return;
        loadingRef.current = true;
        if (echo) setMessages((m)=>[
                ...m,
                {
                    id: nextId.current++,
                    role: "user",
                    text
                }
            ]);
        setInput("");
        setLoading(true);
        const controller = new AbortController();
        abortRef.current = controller;
        const state = {
            id: nextId.current++,
            question: text,
            received: "",
            shown: 0
        };
        streamRef.current = state;
        const history = conversationHistory(messages);
        try {
            const reply = await ask(text, {
                signal: controller.signal,
                history,
                onDelta: (piece)=>{
                    state.received += piece;
                    ensureTimer();
                }
            });
            // The final answer is authoritative: keep what is already visible if it matches, else continue from the match.
            state.shown = Math.min(state.shown, (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$typewriter$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["commonPrefixLength"])(state.received.slice(0, state.shown), reply.answer));
            state.received = reply.answer;
            state.final = reply;
        } catch (error) {
            if (controller.signal.aborted) return; // the Stop button or New chat already took care of it
            state.error = error;
        }
        ensureTimer();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        ask,
        tickMs,
        messages
    ]);
    const sendRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useRef"])(send);
    sendRef.current = send;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const onAsk = (event)=>{
            const question = event.detail;
            if (typeof question !== "string") return;
            setOpen(true);
            void sendRef.current(question);
        };
        window.addEventListener(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ASK_EVENT"], onAsk);
        return ()=>window.removeEventListener(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ASK_EVENT"], onAsk);
    }, []);
    const stop = ()=>{
        const state = streamRef.current;
        if (!state) return;
        abortRef.current?.abort();
        stopTimer();
        streamRef.current = null;
        loadingRef.current = false;
        setLoading(false);
        const partial = state.received.slice(0, state.shown).trim();
        if (partial) show(state, {
            text: partial,
            streaming: false
        });
    };
    const retry = (message)=>{
        if (!message.retryQuestion) return;
        setMessages((m)=>m.filter((x)=>x.id !== message.id));
        void send(message.retryQuestion, false); // the user's bubble is already in the conversation
    };
    const reset = ()=>{
        abortRef.current?.abort();
        stopTimer();
        streamRef.current = null;
        loadingRef.current = false;
        setMessages([]);
        setInput("");
        setLoading(false);
        inputRef.current?.focus();
    };
    const onKeyDown = (e)=>{
        if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
            e.preventDefault(); // Enter sends; Shift+Enter adds a new line
            void send(input);
        }
    };
    const canSend = input.trim().length > 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].root,
        "data-open": open,
        children: [
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                id: panelId,
                role: "dialog",
                "aria-label": "SharpBuild assistant",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].panel,
                onKeyDown: (e)=>{
                    if (e.key === "Escape") setOpen(false);
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].header,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].avatar,
                                "aria-hidden": "true",
                                children: "SB"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 369,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].headerText,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].title,
                                        children: "SharpBuild Assistant"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatWidget.tsx",
                                        lineNumber: 373,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].subtitle,
                                        children: "AI answers from sharpbuild.io"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatWidget.tsx",
                                        lineNumber: 374,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 372,
                                columnNumber: 13
                            }, this),
                            messages.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].iconButton,
                                onClick: reset,
                                "aria-label": "Start a new chat",
                                title: "New chat",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                    d: ICONS.reset
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatWidget.tsx",
                                    lineNumber: 384,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 377,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].iconButton,
                                onClick: ()=>setOpen(false),
                                "aria-label": "Close chat",
                                title: "Close",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                    d: ICONS.close
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatWidget.tsx",
                                    lineNumber: 394,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 387,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ChatWidget.tsx",
                        lineNumber: 368,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: listRef,
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].messages,
                        role: "log",
                        "aria-live": "polite",
                        "aria-label": "Conversation",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].bubble} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].assistant}`,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].plain,
                                    children: "Hi! I can answer questions about SharpBuild's services, process and work, using what's published on sharpbuild.io."
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatWidget.tsx",
                                    lineNumber: 406,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 405,
                                columnNumber: 13
                            }, this),
                            messages.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].starters,
                                children: STARTERS.map((q)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].chip,
                                        onClick: ()=>void send(q),
                                        children: q
                                    }, q, false, {
                                        fileName: "[project]/src/components/ChatWidget.tsx",
                                        lineNumber: 415,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 413,
                                columnNumber: 15
                            }, this),
                            messages.map((m)=>m.role === "user" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].bubble} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].user}`,
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].plain,
                                        children: m.text
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatWidget.tsx",
                                        lineNumber: 430,
                                        columnNumber: 19
                                    }, this)
                                }, m.id, false, {
                                    fileName: "[project]/src/components/ChatWidget.tsx",
                                    lineNumber: 429,
                                    columnNumber: 17
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    "aria-busy": m.streaming ? true : undefined,
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].bubble} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].assistant} ${m.needsHuman ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].notice : ""}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$AnswerBody$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            text: m.text,
                                            caret: m.streaming
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatWidget.tsx",
                                            lineNumber: 438,
                                            columnNumber: 19
                                        }, this),
                                        m.note && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].note,
                                            children: m.note
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatWidget.tsx",
                                            lineNumber: 439,
                                            columnNumber: 30
                                        }, this),
                                        !m.streaming && m.sources.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].sources,
                                            "aria-label": "Sources",
                                            children: m.sources.map((s, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].sourceChip,
                                                        href: s.url,
                                                        target: "_blank",
                                                        rel: "noopener noreferrer",
                                                        title: s.title,
                                                        children: `${i + 1}. ${s.title}`
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/ChatWidget.tsx",
                                                        lineNumber: 444,
                                                        columnNumber: 27
                                                    }, this)
                                                }, s.url, false, {
                                                    fileName: "[project]/src/components/ChatWidget.tsx",
                                                    lineNumber: 443,
                                                    columnNumber: 25
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatWidget.tsx",
                                            lineNumber: 441,
                                            columnNumber: 21
                                        }, this),
                                        m.retryQuestion && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].retry,
                                            onClick: ()=>retry(m),
                                            children: "Try again"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/ChatWidget.tsx",
                                            lineNumber: 456,
                                            columnNumber: 21
                                        }, this),
                                        !m.streaming && m.needsHuman && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(HumanContact, {}, void 0, false, {
                                            fileName: "[project]/src/components/ChatWidget.tsx",
                                            lineNumber: 464,
                                            columnNumber: 52
                                        }, this)
                                    ]
                                }, m.id, true, {
                                    fileName: "[project]/src/components/ChatWidget.tsx",
                                    lineNumber: 433,
                                    columnNumber: 17
                                }, this)),
                            loading && !hasStreamingText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].bubble} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].assistant}`,
                                role: "status",
                                "aria-label": "Assistant is thinking",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].dots,
                                        "aria-hidden": "true",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {}, void 0, false, {
                                                fileName: "[project]/src/components/ChatWidget.tsx",
                                                lineNumber: 476,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {}, void 0, false, {
                                                fileName: "[project]/src/components/ChatWidget.tsx",
                                                lineNumber: 477,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {}, void 0, false, {
                                                fileName: "[project]/src/components/ChatWidget.tsx",
                                                lineNumber: 478,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/ChatWidget.tsx",
                                        lineNumber: 475,
                                        columnNumber: 17
                                    }, this),
                                    slow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].slow,
                                        children: "Still working on it. The AI service is busy right now."
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/ChatWidget.tsx",
                                        lineNumber: 481,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 470,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ChatWidget.tsx",
                        lineNumber: 398,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].form,
                        onSubmit: (e)=>{
                            e.preventDefault();
                            void send(input);
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                ref: inputRef,
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].input,
                                rows: 1,
                                value: input,
                                maxLength: MAX_LENGTH,
                                onChange: (e)=>{
                                    setInput(e.target.value);
                                    e.target.style.height = "auto";
                                    e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
                                },
                                onKeyDown: onKeyDown,
                                placeholder: "Ask about SharpBuild…",
                                "aria-label": "Your question"
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 496,
                                columnNumber: 13
                            }, this),
                            loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].send,
                                onClick: stop,
                                "aria-label": "Stop generating",
                                title: "Stop",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].stopSquare,
                                    "aria-hidden": "true"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatWidget.tsx",
                                    lineNumber: 519,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 512,
                                columnNumber: 15
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].send,
                                disabled: !canSend,
                                "aria-label": "Send",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                    d: ICONS.send
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ChatWidget.tsx",
                                    lineNumber: 528,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 522,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ChatWidget.tsx",
                        lineNumber: 489,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].footnote,
                        children: [
                            input.length >= MAX_LENGTH - 100 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: [
                                    input.length,
                                    "/",
                                    MAX_LENGTH,
                                    " ·",
                                    " "
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/ChatWidget.tsx",
                                lineNumber: 534,
                                columnNumber: 15
                            }, this),
                            "AI can make mistakes. Don't share personal or sensitive information; questions are processed by Google's Gemini API."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ChatWidget.tsx",
                        lineNumber: 532,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ChatWidget.tsx",
                lineNumber: 359,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ChatWidget$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].launcher,
                "aria-expanded": open,
                "aria-controls": open ? panelId : undefined,
                onClick: ()=>setOpen((o)=>!o),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                        d: open ? ICONS.close : ICONS.chat
                    }, void 0, false, {
                        fileName: "[project]/src/components/ChatWidget.tsx",
                        lineNumber: 551,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: open ? "Hide chat" : "Ask the assistant"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ChatWidget.tsx",
                        lineNumber: 552,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/ChatWidget.tsx",
                lineNumber: 544,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ChatWidget.tsx",
        lineNumber: 357,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/components/TryChips.module.css [app-ssr] (css module)", ((__turbopack_context__) => {

__turbopack_context__.v({
  "chip": "TryChips-module__LWUL1G__chip",
  "wrap": "TryChips-module__LWUL1G__wrap",
});
}),
"[project]/src/components/TryChips.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TryChips
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/events.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$TryChips$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/components/TryChips.module.css [app-ssr] (css module)");
"use client";
;
;
;
function TryChips({ questions, label = "Try asking" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$TryChips$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].wrap,
        role: "group",
        "aria-label": label,
        children: questions.map((q)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$TryChips$2e$module$2e$css__$5b$app$2d$ssr$5d$__$28$css__module$29$__["default"].chip,
                onClick: ()=>window.dispatchEvent(new CustomEvent(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$events$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["ASK_EVENT"], {
                        detail: q
                    })),
                children: q
            }, q, false, {
                fileName: "[project]/src/components/TryChips.tsx",
                lineNumber: 13,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/TryChips.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
}),
"[project]/src/lib/chatApi.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ChatApiError",
    ()=>ChatApiError,
    "askQuestion",
    ()=>askQuestion,
    "askQuestionStream",
    ()=>askQuestionStream,
    "isSafeUrl",
    ()=>isSafeUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sse$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/sse.ts [app-ssr] (ecmascript)");
class ChatApiError extends Error {
    kind;
    retryAfterSeconds;
    constructor(kind, message, retryAfterSeconds){
        super(message), this.kind = kind, this.retryAfterSeconds = retryAfterSeconds;
        this.name = "ChatApiError";
    }
}
;
const API_URL = (("TURBOPACK compile-time value", "http://127.0.0.1:8000") ?? "http://127.0.0.1:8000").replace(/\/+$/, "");
function isSafeUrl(value) {
    try {
        const { protocol } = new URL(value);
        return protocol === "https:" || protocol === "http:";
    } catch  {
        return false;
    }
}
function parseReply(data) {
    if (typeof data !== "object" || data === null) return null;
    const { answer, sources, fallback } = data;
    if (typeof answer !== "string" || !Array.isArray(sources)) return null;
    const clean = [];
    for (const s of sources){
        if (typeof s !== "object" || s === null) return null;
        const { url, title, section } = s;
        if (typeof url !== "string" || typeof title !== "string") return null;
        if (isSafeUrl(url)) clean.push({
            url,
            title,
            section: typeof section === "string" ? section : ""
        });
    }
    return {
        answer,
        sources: clean,
        fallback: fallback === true
    };
}
function throwForStatus(response) {
    if (response.status === 429) {
        const seconds = Number(response.headers.get("Retry-After"));
        throw new ChatApiError("rate_limited", "Too many requests.", Number.isFinite(seconds) && seconds > 0 ? seconds : undefined);
    }
    if (response.status === 422) throw new ChatApiError("invalid", "The message was rejected.");
    if (!response.ok) throw new ChatApiError("unavailable", `The assistant returned ${response.status}.`);
}
async function askQuestion(message, signal, fetchImpl = fetch, history = []) {
    let response;
    try {
        response = await fetchImpl(`${API_URL}/chat`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(history.length ? {
                message,
                history
            } : {
                message
            }),
            signal
        });
    } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") throw error;
        throw new ChatApiError("network", "Could not reach the assistant.");
    }
    throwForStatus(response);
    let data;
    try {
        data = await response.json();
    } catch  {
        throw new ChatApiError("unavailable", "The assistant sent an unreadable response.");
    }
    const reply = parseReply(data);
    if (!reply) throw new ChatApiError("unavailable", "The assistant sent an unexpected response.");
    return reply;
}
async function askQuestionStream(message, { signal, onDelta, history = [] } = {}, fetchImpl = fetch) {
    let response;
    try {
        response = await fetchImpl(`${API_URL}/chat/stream`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "text/event-stream"
            },
            body: JSON.stringify(history.length ? {
                message,
                history
            } : {
                message
            }),
            signal
        });
    } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") throw error;
        throw new ChatApiError("network", "Could not reach the assistant.");
    }
    // A backend without the streaming endpoint (older deployment): use the plain endpoint instead.
    if (response.status === 404 || response.status === 405) return askQuestion(message, signal, fetchImpl, history);
    throwForStatus(response);
    let final = null;
    const handle = (event)=>{
        if (typeof event !== "object" || event === null) return;
        const e = event;
        if (e.type === "delta" && typeof e.text === "string") {
            onDelta?.(e.text);
        } else if (e.type === "done") {
            const reply = parseReply(e);
            if (!reply) throw new ChatApiError("unavailable", "The assistant sent an unexpected response.");
            final = reply;
        } else if (e.type === "error") {
            throw new ChatApiError("unavailable", typeof e.message === "string" ? e.message : "The assistant failed.");
        }
    };
    try {
        let buffer = "";
        const reader = response.body?.getReader();
        if (reader) {
            const decoder = new TextDecoder();
            for(;;){
                const { done, value } = await reader.read();
                if (done) break;
                buffer += decoder.decode(value, {
                    stream: true
                });
                const parsed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sse$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseSse"])(buffer);
                buffer = parsed.rest;
                parsed.events.forEach(handle);
            }
            buffer += decoder.decode();
        } else {
            buffer = await response.text(); // no streaming support in this environment: read it all at once
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$sse$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseSse"])(buffer + "\n\n").events.forEach(handle); // a last frame without its blank line
    } catch (error) {
        if (error instanceof ChatApiError) throw error;
        if (error instanceof DOMException && error.name === "AbortError") throw error;
        throw new ChatApiError("network", "The connection was interrupted.");
    }
    if (!final) throw new ChatApiError("unavailable", "The answer ended unexpectedly.");
    return final;
}
}),
"[project]/src/lib/citations.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** The backend removes "[1]" citation markers and returns sources separately. This is a safety net
 *  for an older backend (or a model slip): any marker left in the text is removed before display. */ __turbopack_context__.s([
    "stripCitations",
    ()=>stripCitations
]);
function stripCitations(text) {
    return text.replace(/(\[\d{1,2}(?:\s*,\s*\d{1,2})*\])\s*,\s*(?=\[\d)/g, "$1") // "[1], [2]" -> "[1][2]"
    .replace(/[ \t]*\[\d{1,2}(?:\s*,\s*\d{1,2})*\]/g, "");
}
}),
"[project]/src/lib/events.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** Fired with detail = a question string. The chat widget opens itself and asks it. */ __turbopack_context__.s([
    "ASK_EVENT",
    ()=>ASK_EVENT
]);
const ASK_EVENT = "sharpbuild:ask";
}),
"[project]/src/lib/format.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parseAnswer",
    ()=>parseAnswer,
    "parseInline",
    ()=>parseInline
]);
const NUMBERED = /^\s*(\d{1,2})[.)]\s+(.+)$/;
const BULLET = /^\s*[•*-]\s+(.+)$/;
function parseAnswer(text) {
    const blocks = [];
    let paragraph = [];
    const flush = ()=>{
        if (paragraph.length) blocks.push({
            type: "p",
            text: paragraph.join(" ")
        });
        paragraph = [];
    };
    for (const raw of text.split(/\r?\n/)){
        const line = raw.trim().replace(/^#{1,6}\s+/, ""); // "## Heading" -> "Heading": no headings in a chat bubble
        if (!line) {
            flush();
            continue;
        }
        const numbered = NUMBERED.exec(line);
        const bullet = numbered ? null : BULLET.exec(line);
        const last = blocks[blocks.length - 1];
        if (numbered) {
            flush();
            if (last?.type === "ol" && paragraph.length === 0) last.items.push(numbered[2]);
            else blocks.push({
                type: "ol",
                items: [
                    numbered[2]
                ],
                start: Number(numbered[1])
            });
        } else if (bullet) {
            flush();
            if (last?.type === "ul" && paragraph.length === 0) last.items.push(bullet[1]);
            else blocks.push({
                type: "ul",
                items: [
                    bullet[1]
                ]
            });
        } else {
            paragraph.push(line);
        }
    }
    flush();
    return blocks;
}
function parseInline(text) {
    const parts = text.split("**");
    const unmatched = (parts.length - 1) % 2 === 1;
    const segments = [];
    parts.forEach((part, i)=>{
        if (!part) return;
        segments.push({
            text: part,
            bold: i % 2 === 1 && !(unmatched && i === parts.length - 1)
        });
    });
    return segments;
}
}),
"[project]/src/lib/sse.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** Splits a growing text buffer into complete server-sent events (JSON in "data:" lines).
 *  Returns what it could parse and the unfinished remainder to keep for the next piece. */ __turbopack_context__.s([
    "parseSse",
    ()=>parseSse
]);
function parseSse(buffer) {
    const events = [];
    let rest = buffer;
    for(;;){
        const boundary = /\r?\n\r?\n/.exec(rest);
        if (!boundary) break;
        const frame = rest.slice(0, boundary.index);
        rest = rest.slice(boundary.index + boundary[0].length);
        const data = frame.split(/\r?\n/).filter((line)=>line.startsWith("data:")).map((line)=>line.slice(5).replace(/^ /, "")).join("\n");
        if (!data) continue; // comments such as ": ping", and empty frames
        try {
            events.push(JSON.parse(data));
        } catch  {
        /* a malformed frame is skipped, never fatal */ }
    }
    return {
        events,
        rest
    };
}
}),
"[project]/src/lib/typewriter.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** How many characters should be visible after the next tick. Reveals 2 to 12 characters per tick:
 *  slower when little text is waiting (smooth, readable), faster when a lot has arrived at once
 *  (a whole answer in one piece), so the reveal never falls far behind. */ __turbopack_context__.s([
    "commonPrefixLength",
    ()=>commonPrefixLength,
    "nextShown",
    ()=>nextShown
]);
function nextShown(shown, total) {
    const backlog = total - shown;
    if (backlog <= 0) return total;
    const step = Math.min(12, Math.max(2, Math.ceil(backlog / 18)));
    return Math.min(total, shown + step);
}
function commonPrefixLength(a, b) {
    const max = Math.min(a.length, b.length);
    let i = 0;
    while(i < max && a[i] === b[i])i++;
    return i;
}
}),
];

//# sourceMappingURL=_0yxjd82c_z6u7._.js.map